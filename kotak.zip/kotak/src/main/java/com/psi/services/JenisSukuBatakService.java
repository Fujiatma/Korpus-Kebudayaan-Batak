package com.psi.services;

import java.util.List;

import com.psi.models.JenisSukuBatak;

public interface JenisSukuBatakService {
	public List<JenisSukuBatak> getAllJenisSuku();
}
