package com.psi.services;

import com.psi.models.Log;

public interface LogService {
	Log save(Log log); 
}
